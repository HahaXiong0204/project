#ifndef ADC_H
#define ADC_H

#include "stm32f10x.h"



/**************************��������********************************/
void ADCx_Init(void);






#endif

