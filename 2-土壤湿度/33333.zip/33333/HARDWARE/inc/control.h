
#ifndef __CONTROL_H
#define __CONTROL_H

int length(int a);
void Send_Data(void);
void Send_Data_temperature(void);
#endif


