
#ifndef	__LED_H
#define __LED_H
#include "stm32f10x.h"

void LED_Init(void);//��ʼ��
void led(u8 m);

#endif
