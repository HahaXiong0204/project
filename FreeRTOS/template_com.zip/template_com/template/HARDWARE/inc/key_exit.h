#ifndef _KEY_EXIT_H
#define _KEY_EXIT_H
#include "main.h"

#define PWM_MAC_PWM		400



#endif
